/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


//var urlGl = "https://app.sourcedagile.com/";
var urlGl = "http://localhost:8080/tsn1/";
//var urlGl = ""

function getToken() {
    return 'apdtok=eyJhbGciOiJBMTI4S1ciLCJlbmMiOiJBMTI4Q0JDLUhTMjU2In0.05eOJjllxbQlge6v2MCwIiSlu6joxdvw5aK9m2bjlCx4Y_GH6vMhyA.pdYzkcQZkZzt0bxUZ3smWw.-gbNwXEhor-EBetCcH6RKnRSlN54gZmmZeHrdK_BOLso5ZgPXPFziiDpM-bxFvsqJbJ7eyrz4ly92j8o_H7iGc5Zu4XwQ6sEYMSRZ5tlsZecDRkHaSJrhLSCCHvZkJydze9GCbLS94dk8rnktH9BlZKag3l1h4A7M0DsXRblYxA.7mr0qZrNeIHj7cDRf6dztw';
    //    return '';
}